﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO.Ports;
using System.IO;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;

namespace FishBowl
{
    public partial class Form1 : Form
    {
        private MySqlConnection connection = new MySqlConnection
            ("Server=localhost;Port=3306;Database=fishbowl;Uid=root;Pwd=as19778797;");

        SerialPort ComPort = new SerialPort();
        private delegate void SetTextDelegate(string getString);

        private int LocalPort = 0;
        private static string data_ip = "100.100.100.87";
        private IPAddress LoacalAddress = IPAddress.Parse(data_ip);
        private TcpListener Listener = null;
        private TcpClient Client = null;
        private Thread ListenThread;
        private bool Listening = false;
        private StreamReader Reader;
        private StreamWriter Writer;
        private static bool savingFlag = false;
        private static bool runningFlag = false;

        public Form1()
        {
            InitializeComponent();
            ComPort.DataReceived += new SerialDataReceivedEventHandler(DataReceived);
        }

        private void DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                string rxd = ComPort.ReadTo("\n");
                this.BeginInvoke(new SetTextDelegate(SerialReceived), new object[] { rxd });
            }
            catch (Exception) { }
        }

        private void TCPmsgReceive(string msg)
        {
            txtRxMsg1.AppendText(msg + "\r\n");
            txtRxMsg1.Select(txtRxMsg1.Text.Length, 0);
            txtRxMsg1.ScrollToCaret();
        }

        private void TCPmsgReceive2(string msg)
        {
            string Data = msg.Substring(1);

            string[] PasingData = Data.Split(',');
            double water_temp = Convert.ToDouble(PasingData[0]);
            //double water_turbidity = Convert.ToDouble(PasingData[1]);

            string msg1 = DateTime.Now.ToString("MM-dd") + " - " + DateTime.Now.ToString("HH:mm:ss") + " / " + water_temp.ToString();// + " / " + water_turbidity.ToString();

            txtRxMsg1.AppendText(msg1 + "\r\n");
            txtRxMsg1.Select(txtRxMsg1.Text.Length, 0);
            txtRxMsg1.ScrollToCaret();

            if (txtRxMsg1.Lines.Length >= 20)
            {
                txtRxMsg1.Clear();
            }
        }

        private void Listen()
        {
            try
            {
                Listener = new TcpListener(LoacalAddress, LocalPort);
                Listener.Start();

                while (Listening)
                {
                    Client = Listener.AcceptTcpClient();
                    string msg = "Connected! " + DateTime.Now.ToString("MM-dd") + " - " + DateTime.Now.ToString("HH:mm:ss");
                    this.BeginInvoke(new SetTextDelegate(TCPmsgReceive), new object[] { msg });
                    NetworkStream stream = Client.GetStream();
                    Reader = new StreamReader(stream);
                    Writer = new StreamWriter(stream);
                    while (Client.Connected)
                    {
                        Thread.Sleep(10);
                        if (stream.CanRead)
                        {
                            string strReceived = Reader.ReadLine();
                            
                            if (strReceived.Length > 0)
                            {
                                string Head = strReceived.Substring(0, 1);
                                string Data = strReceived.Substring(1);

                                if (Head == "@" && button1.Text == "Disconnect" && button2.Text == "Release")
                                {

                                    this.BeginInvoke(new SetTextDelegate(TCPmsgReceive2), new object[] { strReceived });

                                    /*
                                    string[] PasingData = Data.Split(',');
                                    double water_temp = Convert.ToDouble(PasingData[0]);
                                    double water_turbidity = Convert.ToDouble(PasingData[1]);
                                    */
                                    double water_temp = Convert.ToDouble(Data);
                                    try
                                    {
                                        InsertData(water_temp);
                                    }
                                    catch
                                    {
                                        //
                                    }
                                    /*
                                    label10.Invoke((MethodInvoker)delegate ()
                                    {
                                        label10.Text = PasingData[0];
                                    });

                                    label9.Invoke((MethodInvoker)delegate ()
                                    {
                                        label9.Text = PasingData[1];
                                    });
                                    */

                                    label10.Invoke((MethodInvoker)delegate()
                                    {
                                        label10.Text = Data;
                                    });


                                }
                            }
                            
                        }
                        
                    }
                    Client.Close();
                }
            }
            catch (SocketException ex)
            {
                MessageBox.Show(ex.Message.ToString(), "TCP Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SerialReceived(string inString)
        {
            try
            {
                string Head = inString.Substring(0, 1);
                string Data = inString.Substring(1);

                if (Head == "@" && button2.Text == "Release")
                {
                    /*
                    string[] PasingData = Data.Split(',');
                    double water_temp = Convert.ToDouble(PasingData[0]);
                    double water_turbidity = Convert.ToDouble(PasingData[1]);
                    InsertData(water_temp, water_turbidity);

                    label1.Text = PasingData[0];
                    label2.Text = PasingData[1];
                    */

                    double water_temp = Convert.ToDouble(Data);

                    InsertData(water_temp);

                }
                else
                {
                    
                }

            }
            catch (Exception)
            {
                toolStripStatusLabel1.Text = "Serial Error!";
            }
        }

        private void SerialWrite(string str)
        {
            try
            {
                if (ComPort.IsOpen)
                {
                    string msg = "$" + str + "\n";
                    ComPort.Write(msg);
                }
            }
            catch { }
        }

        public bool mySql_Open()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot contact MySQL Server", "mySQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again", "mySQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    default:
                        MessageBox.Show(ex.ToString(), "mySQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
                return false;
            }
        }

        public bool mySql_Close()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void InsertData(double Data_1)
        {
            try
            {
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "INSERT INTO sensing_data(Date, Time, water_temp) VALUES(@date,@time,@temp)";
                command.Parameters.Add("@date", MySqlDbType.VarChar).Value = DateTime.Now.ToString("MM-dd");
                command.Parameters.Add("@time", MySqlDbType.VarChar).Value = DateTime.Now.ToString("HH:mm");
                command.Parameters.Add("@temp", MySqlDbType.VarChar).Value = Data_1.ToString();
                //command.Parameters.Add("@turbidity", MySqlDbType.VarChar).Value = Data_2.ToString();
                command.ExecuteNonQuery();

                if (btnConnect.Text == "Release")
                {
                    //richTextBox1.AppendText(DateTime.Now.ToString("dd-MM-yyyy") + " - " + DateTime.Now.ToString("HH:mm:ss") + " / " + Data_1.ToString() + " / " + Data_2.ToString() + "\n");
                    richTextBox1.AppendText(DateTime.Now.ToString("MM-dd") + " - " + DateTime.Now.ToString("HH:mm") + " / " + Data_1.ToString() + "\n");
                    richTextBox1.SelectionStart = richTextBox1.TextLength;
                    richTextBox1.ScrollToCaret();

                    if (richTextBox1.Lines.Length >= 20)
                    {
                        richTextBox1.Clear();
                    }
                }
                /*
                if (button1.Text == "Disconnect")
                {
                    txtRxMsg1.AppendText(DateTime.Now.ToString("dd-MM-yyyy") + " - " + DateTime.Now.ToString("HH:mm:ss") + " / " + Data_1.ToString() + " / " + Data_2.ToString() + "\n");
                    txtRxMsg1.SelectionStart = richTextBox1.TextLength;
                    txtRxMsg1.ScrollToCaret();
                }
                */
            }
            catch
            {
                toolStripStatusLabel1.ForeColor = System.Drawing.Color.Red;
                toolStripStatusLabel1.Text = "DB Connection must be preceded!";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button2.BackColor = Color.DarkGray;
            button2.Enabled = false;
            button3.Enabled = false;

            cmbComPort.Items.Clear();
            var portName = System.IO.Ports.SerialPort.GetPortNames();
            cmbComPort.Items.AddRange(portName);
            cmbComPort.SelectedIndex = cmbComPort.Items.Count - 1;
            cmbBoardRate.Items.Clear();
            cmbBoardRate.Items.Add("9600");
            cmbBoardRate.Items.Add("19200");
            cmbBoardRate.Items.Add("57600");
            cmbBoardRate.Items.Add("115200");
            try
            {
                cmbBoardRate.SelectedIndex = 3;
            }
            catch (Exception)
            {
                cmbBoardRate.SelectedIndex = 0;
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (btnConnect.Text == "Connect")
            {
                ComPort.PortName = cmbComPort.Text;
                ComPort.BaudRate = Convert.ToInt32(cmbBoardRate.Text);
                ComPort.DataBits = 8;
                ComPort.Parity = Parity.None;
                ComPort.StopBits = StopBits.One;
                ComPort.Handshake = Handshake.None;
                ComPort.Open();
                ComPort.DiscardInBuffer();
                btnConnect.Text = "Release";
                toolStripLabel1.ForeColor = Color.Lime;
                toolStripLabel1.Text = "===";
                button2.Enabled = true;
                button1.Enabled = false;
            }
            else
            {
                ComPort.Close();
                btnConnect.Text = "Connect";
                toolStripLabel1.ForeColor = Color.Red;
                toolStripLabel1.Text = "=/=";
                button2.Enabled = false;
                button1.Enabled = true;

                if (mySql_Close())
                {
                    picDB.BackColor = Color.Transparent;
                    button2.BackColor = Color.DarkGray;
                    toolStripStatusLabel1.Text = "DB Closed.";
                    button2.Text = "Connect";
                    button3.Enabled = false;
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (ListenThread != null) ListenThread.Abort();
            if (Listener != null) Listener.Stop();
            if (Client != null) Client.Close();
            if (Reader != null) Reader.Close();
            if (Writer != null) Writer.Close();

            try
            {
                if (ComPort != null)
                {
                    ComPort.Close();
                }
                else
                {
                    ComPort.Dispose();
                    ComPort = null;
                }
            }
            catch(System.NullReferenceException)
            {
                ComPort.Dispose();
                ComPort = null;
            }

            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;

            if (textBox3.Text != null && int.TryParse(textBox4.Text, out i))
            {
                data_ip = textBox3.Text;
                LocalPort = Convert.ToInt16(textBox4.Text);

                if (button1.Text == "Listen")
                {
                    Listening = true;
                    ListenThread = new Thread(new ThreadStart(Listen));
                    ListenThread.Start();
                    button1.Text = "Disconnect";
                    txtRxMsg1.AppendText("Data receiving Start!\r\n");
                    txtRxMsg1.Select(txtRxMsg1.Text.Length, 0);
                    txtRxMsg1.ScrollToCaret();
                    textBox3.Enabled = false;
                    textBox4.Enabled = false;
                    btnConnect.Enabled = false;
                    button2.Enabled = true;
                }
                else
                {
                    button1.Text = "Listen";
                    Listening = false;
                    Listener.Stop();
                    ListenThread.Abort();
                    txtRxMsg1.AppendText("Data receiving Close!\r\n");
                    txtRxMsg1.Select(txtRxMsg1.Text.Length, 0);
                    txtRxMsg1.ScrollToCaret();
                    textBox3.Enabled = true;
                    textBox4.Enabled = true;
                    btnConnect.Enabled = true;
                    button2.Enabled = false;

                    if (mySql_Close())
                    {
                        picDB.BackColor = Color.Transparent;
                        button2.BackColor = Color.DarkGray;
                        toolStripStatusLabel1.Text = "DB Closed.";
                        button2.Text = "Connect";
                        button3.Enabled = false;
                    }
                }
            }
            else 
            {
                txtRxMsg1.AppendText("Please, check the input values.\n");
                txtRxMsg1.Select(txtRxMsg1.Text.Length, 0);
                txtRxMsg1.ScrollToCaret();
            }

            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Thread thread03 = new Thread(() => pythonRun());
            thread03.Start();

            if (button2.BackColor == Color.DarkGray)
            {
                if (mySql_Open())
                {
                    picDB.BackColor = Color.LawnGreen;
                    button2.BackColor = Color.LawnGreen;
                    button2.Text = "Release";
                    toolStripStatusLabel1.Text = "Connection Ok.";
                    button3.Enabled = true;

                }
                else
                {
                    picDB.BackColor = Color.Coral;
                    button2.BackColor = Color.Coral;
                    toolStripStatusLabel1.Text = "Connection Failed.";
                    button3.Enabled = false;

                }
            }
            else
            {
                if (mySql_Close())
                {
                    picDB.BackColor = Color.Transparent;
                    button2.BackColor = Color.DarkGray;
                    toolStripStatusLabel1.Text = "DB Closed.";
                    button2.Text = "Connect";
                    button3.Enabled = false;
                }
                else
                {
                    picDB.BackColor = Color.Coral;
                    button2.BackColor = Color.Coral;
                    toolStripStatusLabel1.Text = "DB Closing Failed.";
                    button3.Enabled = false;
                }
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (connection.State == ConnectionState.Open)
            {
                try
                {

                    string sql = "SELECT * FROM sensing_data;";
                    MySqlCommand command = new MySqlCommand(sql, connection);
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;

                }

                catch
                {
                    toolStripStatusLabel1.Text = "SQL Query Failed. Please, check your connection";
                }
            }
        }

        private static void Save_CmdExecute()
        {
            runningFlag = true;

            System.Diagnostics.ProcessStartInfo pri = new System.Diagnostics.ProcessStartInfo();
            System.Diagnostics.Process pro = new System.Diagnostics.Process();

            //실행할 파일 명 입력하기
            pri.FileName = "cmd.exe";

            //cmd 창 띄우기
            pri.CreateNoWindow = false; //flase가 띄우기, true가 안 띄우기
            pri.UseShellExecute = false;

            pri.RedirectStandardInput = true;
            pri.RedirectStandardOutput = true;
            pri.RedirectStandardError = true;

            pro.StartInfo = pri;
            pro.Start();

            //명령어 실행
            pro.StandardInput.Write(@"call C:\Users\User\anaconda3\Scripts\activate.bat" + Environment.NewLine);
            pro.StandardInput.Write(@"call conda activate tracker-gpu" + Environment.NewLine);
            pro.StandardInput.Write(@"call cd C:\Users\User\Desktop\yolov3_deepsort-master" + Environment.NewLine);
            pro.StandardInput.Write(@"python savingWebVideo.py" + Environment.NewLine);
            pro.StandardInput.Write(@"call conda deactivate" + Environment.NewLine);
            pro.StandardInput.Close();
            string resultValue = pro.StandardOutput.ReadToEnd();
            pro.WaitForExit();
            pro.Close();

            savingFlag = true;
            runningFlag = false;

            //결과 텍스트 띄우기(프로세스 멈출 수 있음)
            //MessageBox.Show(resultValue);savingWebVideo.py

        }

        private static void Analysis_CmdExecute()
        {
            runningFlag = true;

            System.Diagnostics.ProcessStartInfo pri = new System.Diagnostics.ProcessStartInfo();
            System.Diagnostics.Process pro = new System.Diagnostics.Process();

            //실행할 파일 명 입력하기
            pri.FileName = "cmd.exe";

            //cmd 창 띄우기
            pri.CreateNoWindow = false; //flase가 띄우기, true가 안 띄우기
            pri.UseShellExecute = false;

            pri.RedirectStandardInput = true;
            pri.RedirectStandardOutput = true;
            pri.RedirectStandardError = true;

            pro.StartInfo = pri;
            pro.Start();

            //명령어 실행
            pro.StandardInput.Write(@"call C:\Users\User\anaconda3\Scripts\activate.bat" + Environment.NewLine);
            pro.StandardInput.Write(@"call conda activate tracker-gpu" + Environment.NewLine);
            pro.StandardInput.Write(@"call cd C:\Users\User\Desktop\yolov3_deepsort-master" + Environment.NewLine);
            pro.StandardInput.Write(@"python object_tracker.py --video ./data/video/web_video.avi --output ./data/video/results.avi --weights ./weights/yolov3-custom.tf --num_classes 1 --classes ./data/labels/classes.names" + Environment.NewLine);
            pro.StandardInput.Write(@"call conda deactivate" + Environment.NewLine);
            pro.StandardInput.Close();
            string resultValue = pro.StandardOutput.ReadToEnd();
            pro.WaitForExit();
            pro.Close();

            savingFlag = false;
            runningFlag = false;

            //결과 텍스트 띄우기(프로세스 멈출 수 있음)
            //MessageBox.Show(resultValue);savingWebVideo.py

        }

        private static void pythonRun()
        {
            while (true)
            {
                if (savingFlag == false && runningFlag == false)
                {
                    Thread thread01 = new Thread(() => Save_CmdExecute());
                    thread01.Start();
                }
                if (savingFlag == true && runningFlag == false)
                {
                    Thread thread02 = new Thread(() => Analysis_CmdExecute());
                    thread02.Start();
                }
                Thread.Sleep(10);
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
